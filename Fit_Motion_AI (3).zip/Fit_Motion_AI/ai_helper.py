
import requests

OLLAMA_URL = "http://localhost:11434/api/chat"
MODEL_NAME = "gemma4:e2b"

def ask_gemma(prompt):
    try:
        response = requests.post(
            OLLAMA_URL,
            json={
                "model": MODEL_NAME,
                "messages": [
                    {"role": "user", "content": prompt}
                ],
                "stream": False
            },
            timeout=(10, 600)
        )

        response.raise_for_status()
        data = response.json()

        return data["message"]["content"]

    except requests.exceptions.ConnectionError:
        return (
            "Cannot connect to Ollama. "
            "Please start Ollama and try again."
        )

    except requests.exceptions.Timeout:
        return (
            "Gemma is taking too long to respond. "
            "Try a shorter question."
        )

    except Exception as error:
        return f"AI request failed: {error}"